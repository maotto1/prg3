
public class JUnitTest {

	public static void main(String[] args) {
		// TODO Automatisch generierter Methodenstub
		StorageTest test = new StorageTest();
	}

}

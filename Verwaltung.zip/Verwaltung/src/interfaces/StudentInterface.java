package interfaces;

public interface StudentInterface {
	
	public int getMatrikelNumber();
	public int getSemester();
	public String getUniversity();
	public String getCourse();
	public String getDegree();
	public void incrementSemester();

}

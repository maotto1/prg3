package interfaces;

public interface Output {

	public void printInstances();
	public void printInstancesSortedByType();
	public void search(String search);
}
